# Yusupha Bah - Portfolio Website

A modern, responsive portfolio website showcasing my skills, projects, and professional experience as a Full Stack Developer.

## 🌟 Features

### Design & UX
- **Modern Design**: Clean, professional layout with gradient accents
- **Responsive**: Fully responsive design that works on all devices
- **Smooth Animations**: CSS animations and JavaScript interactions
- **Dark/Light Theme**: Professional color scheme with CSS variables
- **Typography**: Beautiful typography using Inter font family

### Sections
- **Hero Section**: Eye-catching introduction with profile image
- **About**: Professional background and statistics
- **Skills**: Categorized technical skills with visual tags
- **Projects**: Featured projects with descriptions and links
- **Contact**: Contact form and social media links

### Interactive Elements
- **Mobile Navigation**: Hamburger menu for mobile devices
- **Smooth Scrolling**: Navigation links with smooth scroll behavior
- **Hover Effects**: Interactive hover animations on cards and buttons
- **Form Validation**: Contact form with client-side validation
- **Loading Animation**: Professional preloader animation

## 🚀 Technologies Used

- **HTML5**: Semantic markup structure
- **CSS3**: Modern styling with CSS Grid, Flexbox, and animations
- **JavaScript**: Interactive functionality and animations
- **Font Awesome**: Icons for projects and social links
- **Google Fonts**: Inter font family for typography

## 📁 Project Structure

```
portfolio/
├── index.html          # Main HTML file
├── style.css           # CSS styles and animations
├── script.js           # JavaScript functionality
├── README.md           # Project documentation
└── image/              # Image assets
    └── profile.jpg     # Profile picture
```

## 🎨 Design Features

### Color Scheme
- **Primary**: Indigo gradient (#6366f1 to #764ba2)
- **Secondary**: Emerald green (#10b981)
- **Accent**: Amber (#f59e0b)
- **Text**: Dark gray (#1f2937) and light gray (#6b7280)
- **Background**: White (#ffffff) and light gray (#f9fafb)

### Typography
- **Font Family**: Inter (Google Fonts)
- **Headings**: Bold weights (600-700)
- **Body Text**: Regular weight (400)
- **Responsive**: Font sizes scale with screen size

### Animations
- **Fade-in animations** for sections
- **Hover effects** on cards and buttons
- **Smooth transitions** throughout the site
- **Parallax scrolling** effects
- **Typing animation** for hero title

## 📱 Responsive Design

The website is fully responsive and optimized for:
- **Desktop**: 1200px and above
- **Tablet**: 768px to 1199px
- **Mobile**: 480px to 767px
- **Small Mobile**: Below 480px

### Mobile Features
- Collapsible navigation menu
- Touch-friendly buttons and links
- Optimized typography scaling
- Simplified layouts for small screens

## 🛠️ Setup Instructions

1. **Clone or Download** the project files
2. **Open** `index.html` in your web browser
3. **Customize** the content in `index.html`:
   - Update personal information
   - Add your own projects
   - Modify contact details
   - Replace profile image

### Customization Guide

#### Personal Information
```html
<!-- Update in index.html -->
<h1 class="hero-title">Hi, I'm <span class="highlight">Your Name</span> 👋</h1>
<p class="hero-subtitle">Your Title</p>
```

#### Projects
```html
<!-- Add your projects in the projects section -->
<div class="project-card">
  <div class="project-image">
    <i class="fas fa-icon-name"></i>
  </div>
  <div class="project-content">
    <h3>Project Name</h3>
    <p>Project description...</p>
    <div class="project-tech">
      <span>Technology</span>
    </div>
  </div>
</div>
```

#### Skills
```html
<!-- Update skills in the skills section -->
<div class="skill-category">
  <h3>Category</h3>
  <div class="skill-items">
    <span class="skill-item">Skill Name</span>
  </div>
</div>
```

## 📧 Contact Form

The contact form includes:
- **Name field** (required)
- **Email field** (required)
- **Message field** (required)
- **Client-side validation**
- **Success feedback**

Note: The form currently shows a success message. To make it functional, you'll need to:
1. Set up a backend server
2. Configure email sending
3. Update the form action URL

## 🎯 Performance Optimizations

- **Optimized images** for web
- **Minimal JavaScript** for fast loading
- **CSS animations** using transform properties
- **Lazy loading** for better performance
- **Compressed assets** for faster loading

## 🔧 Browser Support

- **Chrome**: 90+
- **Firefox**: 88+
- **Safari**: 14+
- **Edge**: 90+

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Feel free to fork this project and customize it for your own portfolio. If you find any bugs or have suggestions for improvements, please open an issue or submit a pull request.

## 📞 Contact

- **Email**: bahy5098@gmail.com
- **GitHub**: [YusuphaBah](https://github.com/YusuphaBah)
- **LinkedIn**: [Yusupha Bah](https://linkedin.com/in/YusuphaBah)

---

**Built with ❤️ by Yusupha Bah** 